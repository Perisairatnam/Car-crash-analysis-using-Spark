package spark.jobserver

import com.typesafe.config.{Config, ConfigFactory}
import org.apache.spark.{SparkConf, SparkContext}
import org.scalactic._

import scala.util.Try
import spark.jobserver.api.{SparkJob, _}


/**
 * @author training
 */
object driveresult extends SparkJob {
  
  def main(args: Array[String]) {
    val conf = new SparkConf().setMaster("local[4]").setAppName("driveresult")
    val sc = new SparkContext(conf)
    val config = ConfigFactory.parseString("")
    val results = runJob(sc, config)
    println("Result is " + results)
  }

  override def validate(sc: SparkContext, config: Config): SparkJobValidation = {
    Try(config.getString("input.string"))
      .map(x => SparkJobValid)
      .getOrElse(SparkJobInvalid("No input.string config param"))
  }

  override def runJob(sc: SparkContext, config: Config): Any = {
    val input = sc.textFile(config.getString("input.string"))

    val weekend = input.filter(x=>(x.split(",")(7)=="Sunday" || x.split(",")(7)=="saturday" ))
    val age = weekend
    .filter(_.split(",")(24)<="18Years")
    val drunk =age
    .filter(x=>(x.split(",")(46).contains("Yes")))
    val injury = drunk.filter(_.split(",")(40).contains("Fatal"))
    val result = injury.map(_.split(",")).map(row=>(row(89),row(89))).map(x=>(x,1)).reduceByKey((x,y)=>x+y)
        
    result.countByKey()
  }
}
